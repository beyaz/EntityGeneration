﻿using System;
using System.Data.SqlClient;
using BOA.Business.Kernel.Card.ERP.Repository;
using BOA.Types.Kernel.Card.ERP;
using Dapper;
using DotNetDatabaseAccessUtilities;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BOA.EntityGeneration.SchemaToEntityExporting
{
    [TestClass]
    public class SampleDatabaseTest
    {
        const string ConnectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = d:\temp\SampleDatabase.mdf; Integrated Security = True";

        [TestCleanup]
        public void Cleanup()
        {
            new SqlConnection(ConnectionString).Query("TRUNCATE TABLE ERP.SAMPLE_TABLE");
            new SqlConnection(ConnectionString).Query("TRUNCATE TABLE ERP.SAMPLE_TABLE2");
        }

        #region Public Methods
        [TestMethod]
        public void AllScenario()
        {
            var sqlDatabase = new SqlDatabase(ConnectionString);
            
            TestDmlOperations(sqlDatabase);
        }
        #endregion

        static void TestDmlOperations(IDatabase database)
        {
            var repository = new ERPRepository(database);

            var contract = new SampleTableContract
            {
                FieldVarbinary                = new byte[] {8},
                FieldChar                     = "y",
                FieldNchar                    = "t      ",
                FieldVarchar50                = "y",
                FieldNvarchar                 = "5",
                FieldVarchar50Nullable        = "y",
                RowGuid                       = "y",
                FieldSmalldatetime            = DateTime.Today,
                FieldDatetime                 = DateTime.Today,
                FieldDatetimeNullable         = DateTime.Today,
                FieldNumeric270Nullable       = 4,
                FieldIntNullable              = 5,
                FieldMoneyNullable            = 57.7M,
                FieldNvarcharNullable         = "012",
                FieldNcharNullable            = "4      ",
                FieldSmalldatetimeNullable    = DateTime.Today,
                FieldBigintNullable           = 6,
                FieldBitNullable              = true,
                FieldCharNullable             = "1",
                FieldDecimalNullable          = 3,
                FieldSmallintNullable         = 3,
                FieldTinyintNullable          = 5,
                FieldUniqueidentifierNullable = new Guid(),
                FieldVarbinaryNullable        = new byte[] {8},
                FieldIndex33                  = 4,
                UpdateDate                    = DateTime.Today,
                UpdateUserId                  = "5",
                UpdateTokenId                 = "5",
            };

            repository.CreateSampleTable(contract);

            contract.SampleTableId.Should().Be(1);

            var dbRecord = repository.GetSampleTableBySampleTableId(contract.SampleTableId);

            dbRecord.InsertDate = contract.InsertDate;
            dbRecord.Should().BeEquivalentTo(contract);

            contract.FieldNvarcharNullable  = "012345";
            contract.FieldVarchar50Nullable = "uop";
            contract.FieldCharValidFlag = true;

            repository.ModifySampleTable(contract);

            dbRecord = repository.GetSampleTableBySampleTableId(contract.SampleTableId);

            dbRecord.FieldNvarcharNullable.Should().Be("012345");
            dbRecord.FieldVarchar50Nullable.Should().Be("uop");
            contract.FieldCharValidFlag.Should().BeTrue();

            dbRecord.UpdateDate = contract.UpdateDate;
            dbRecord.InsertDate = contract.InsertDate;
            dbRecord.Should().BeEquivalentTo(contract);

            repository.DeleteSampleTable(dbRecord.SampleTableId);
        }
    }
}